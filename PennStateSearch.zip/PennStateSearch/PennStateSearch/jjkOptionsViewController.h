//
// Name:    Joshua Kuiros
// Section: CMPSC 475
// Program: Assignment 9
// Date: October 31, 2013
//

#import <UIKit/UIKit.h>

@interface jjkOptionsViewController : UIViewController
@property(nonatomic,copy) void (^CompletionBlock)(void);
@end
