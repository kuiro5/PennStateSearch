//
// Name:    Joshua Kuiros
// Section: CMPSC 475
// Program: Assignment 8
// Date: October 24, 2013
//
#import "Building.h"


@implementation Building

@dynamic name;
@dynamic latitude;
@dynamic longitude;
@dynamic opp_bldg_code;
@dynamic year_constructed;
@dynamic photoName;
@dynamic photo;

@end
