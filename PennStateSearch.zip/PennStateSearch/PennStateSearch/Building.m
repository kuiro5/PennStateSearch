//
// Name:    Joshua Kuiros
// Section: CMPSC 475
// Program: Assignment 9
// Date: October 31, 2013
//

#import "Building.h"


@implementation Building

@dynamic name;
@dynamic latitude;
@dynamic longitude;
@dynamic opp_bldg_code;
@dynamic year_constructed;
@dynamic photoName;
@dynamic photo;
@dynamic info;
@end
