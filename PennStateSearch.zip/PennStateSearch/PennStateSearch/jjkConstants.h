//
//  jjkConstants.h
//  PennStateSearch
//
//  Created by Joshua Kuiros on 10/15/13.
//  Copyright (c) 2013 Joshua Kuiros. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface jjkConstants : NSObject

FOUNDATION_EXPORT NSString * const buildingsWithPhotos;
FOUNDATION_EXPORT NSString * const buildingsZoom;

@end
