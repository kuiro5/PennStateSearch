//
//  jjkConstants.m
//  PennStateSearch
//
//  Created by Joshua Kuiros on 10/15/13.
//  Copyright (c) 2013 Joshua Kuiros. All rights reserved.
//

#import "jjkConstants.h"

@implementation jjkConstants

NSString * const buildingsWithPhotos = @"ShowBuildingsWithPhotos";
NSString * const buildingsZoom = @"BuildingsZoom";

@end
